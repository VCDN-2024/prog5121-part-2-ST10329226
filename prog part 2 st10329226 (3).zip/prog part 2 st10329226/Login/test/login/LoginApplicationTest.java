
package login;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LoginApplicationTest {

  private LoginApplication app;

  @BeforeEach
   public void setUp() {
        app = new LoginApplication();
    }

    @Test
    public void testIsValidUsername() {
        assertTrue(app.isValidUsername("user_1"));
        assertFalse(app.isValidUsername("username"));
        assertFalse(app.isValidUsername("user_12"));
        assertFalse(app.isValidUsername("user"));
    }

    @Test
    public void testIsValidPassword()
    {
        assertTrue(app.isValidPassword("Passw0rd!"));
        assertFalse(app.isValidPassword("password"));
        assertFalse(app.isValidPassword("Password"));
        assertFalse(app.isValidPassword("Passw0rd"));
    }

    @Test
    public void testTaskDescriptionLength() 
    {
        LoginApplication.Task task = app.new Task("TestTask", "This is a valid description", "Dev", 10, "To Do");
        assertTrue(task.checkTaskDescription());

        LoginApplication.Task task2 = app.new Task("TestTask", "This description is way too long and should fail the validation check because it exceeds fifty characters", "Dev", 10, "To Do");
        assertFalse(task2.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID()
    {
        LoginApplication.Task task = app.new Task("TestTask", "Description", "Developer", 10, "To Do");
        String taskId = task.createTaskID();
        assertTrue(taskId.matches("TE:\\d+:PER"));
    }

    @Test
    public void testPrintTaskDetails() 
    {
        LoginApplication.Task task = app.new Task("TestTask", "Description", "Developer", 10, "To Do");
        String details = task.printTaskDetails();
        assertTrue(details.contains("Task Status: To Do"));
        assertTrue(details.contains("Developer Details: Developer"));
        assertTrue(details.contains("Task Name: TestTask"));
        assertTrue(details.contains("Task Description: Description"));
    }

    @Test
    public void testAddTasks() {
        // Simulate adding tasks (normally this requires user input)
        
        // For this test, we'll manually add tasks to the app's task list

        LoginApplication.Task task1 = app.new Task("Task1", "Description1", "Dev1", 5, "To Do");
        
        LoginApplication.Task task2 = app.new Task("Task2", "Description2", "Dev2", 3, "Done");

        app.tasks.put(task1.getTaskId(), task1);
        
        app.tasks.put(task2.getTaskId(), task2);

        assertEquals(2, app.tasks.size());
        assertEquals(5, app.tasks.get(1).getTaskDuration());
        assertEquals(3, app.tasks.get(2).getTaskDuration());
    }
}